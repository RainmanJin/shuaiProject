function search(){
  $(".search").bind("click",function(){
    $(".search-cont").fadeToggle();
  })
}
search();

function menuToggle(){
  if($("#sidebar").attr("show") == 0) {
    var mainWidth = $(window).width();
    $(".float-block").show();
    $("#main-cont").css('width',$(window).width());
    $("#main-cont").animate({right:"212px"});
    $("#sidebar").animate({right:0}).andSelf().attr("show",1);
  }else {
    $(".float-block").hide();
    $("#main-cont").css('width',"100%");
    $("#sidebar").animate({right:"-212px"}).andSelf().attr("show",0);
    $("#main-cont").animate({right:0});
  }
}
$("#menu-bar,.float-block").click(function(){menuToggle()})