//把main.js中的j 还原成$
var $  = jQuery.noConflict();
